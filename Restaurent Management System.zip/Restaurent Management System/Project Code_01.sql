drop TABLE Feedback;
drop TABLE Reservations;
drop TABLE Tables;
drop TABLE Suppliers;
drop TABLE Inventory;
drop TABLE Employees;

drop TABLE Orders;

drop table MenuItems;
drop TABLE Customers;


CREATE TABLE Customers (
  customer_id INT PRIMARY KEY,
  name VARCHAR(100),
  address VARCHAR(200),
  phone_number VARCHAR(20),
  email VARCHAR(100),
  gender VARCHAR(20)
);


insert into Customers (customer_id, name, address, phone_number, email, gender) VALUES (1, 'John Doe', '123 Main St', '555-555-5555', 'johndoe@email.com', 'Male');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (2, 'Jane Doe', '456 Elm St', '555-555-5556', 'janedoe@email.com', 'Female');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (3, 'Bob Smith', '789 Oak St', '555-555-5557', 'bobsmith@email.com', 'Male');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (4, 'Sally Johnson', '246 Pine St', '555-555-5558', 'sallyjohnson@email.com', 'Female');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (5, 'Tom Davis', '369 Cedar St', '555-555-5559', 'tomdavis@email.com', 'Male');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (6, 'Emily Brown', '159 Maple St', '555-555-5560', 'emilybrown@email.com', 'Female');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (7, 'Michael Jackson', '753 Cedar St', '555-555-5561', 'michaeljackson@email.com', 'Male');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (8, 'Kim Kardashian', '951 Maple St', '555-555-5562', 'kimkardashian@email.com', 'Female');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (9, 'David Beckham', '147 Cedar St', '555-555-5563', 'davidbeckham@email.com', 'Male');
INSERT INTO Customers (customer_id, name, address, phone_number, email, gender) VALUES (10, 'Jennifer Lopez', '753 Elm St', '555-555-5564', 'jenniferlopez@email.com', 'Female');


CREATE TABLE MenuItems (
  item_id INT PRIMARY KEY,
  name VARCHAR(100),
  description VARCHAR(200),
  price NUMBER(10, 2),
  category VARCHAR(50)
);

CREATE TABLE Orders (
  order_id INT PRIMARY KEY,
  customer_id INT,
  order_date DATE,
  quantity NUMBER(10,2),
  total_amount NUMBER(10, 2),
  item_id INT,
  FOREIGN KEY (item_id) REFERENCES MenuItems(item_id),
  FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Employees (
  employee_id INT PRIMARY KEY,
  name VARCHAR(100),
  position VARCHAR(50),
  phone_number VARCHAR(20),
  email VARCHAR(100)
);
CREATE TABLE Inventory (
  item_id INT PRIMARY KEY,
  quantity INT,
  reorder_point INT,
  cost NUMBER(10, 2),
  FOREIGN KEY (item_id) REFERENCES MenuItems(item_id)
);

CREATE TABLE Suppliers (
  supplier_id INT PRIMARY KEY,
  name VARCHAR(100),
  address VARCHAR(200),
  phone_number VARCHAR(20),
  email VARCHAR(100)
);
CREATE TABLE Tables (
  table_id INT PRIMARY KEY,
  seats INT,
  status VARCHAR(20)
);
CREATE TABLE Reservations (
  reservation_id INT PRIMARY KEY,
  customer_id INT,
  table_id INT,
  reservation_date DATE,
  guests INT,
  FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
  FOREIGN KEY (table_id) REFERENCES Tables(table_id)
);
Create TABLE Feedback (
fid INT PRIMARY KEY,
customer_id INT,
item_id INT,
message VARCHAR(50),
FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
FOREIGN KEY (item_id) REFERENCES MenuItems(item_id)
);



insert into Tables values(1,6,'booked');
insert into Tables values(2,4,'booked');
insert into Tables values(3,5,'free');

insert into money@site_link values(4,'D',140);