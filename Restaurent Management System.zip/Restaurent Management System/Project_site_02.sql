drop TABLE Feedback2;

drop TABLE Tables2;


drop TABLE Orders2;

drop table MenuItems2;
drop TABLE Customers2;




CREATE TABLE Customers2 (
  customer_id INT PRIMARY KEY ,
  phone_number VARCHAR(20),
  email VARCHAR(100),
  gender VARCHAR(20)
);





insert into Customers2 (customer_id,  phone_number, email, gender) VALUES (1,  '555-555-5555', 'johndoe@email.com', 'Male');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (2,  '555-555-5556', 'janedoe@email.com', 'Female');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (3,  '555-555-5557', 'bobsmith@email.com', 'Male');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (4,  '555-555-5558', 'sallyjohnson@email.com', 'Female');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (5,  '555-555-5559', 'tomdavis@email.com', 'Male');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (6, '555-555-5560', 'emilybrown@email.com', 'Female');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (7,  '555-555-5561', 'michaeljackson@email.com', 'Male');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (8,  '555-555-5562', 'kimkardashian@email.com', 'Female');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (9,  '555-555-5563', 'davidbeckham@email.com', 'Male');
INSERT INTO Customers2 (customer_id,  phone_number, email, gender) VALUES (10, '555-555-5564', 'jenniferlopez@email.com', 'Female');





CREATE TABLE MenuItems2 (
  item_id INT PRIMARY KEY,
  name VARCHAR(100),
  description VARCHAR(200),
  price NUMBER(10, 2),
  category VARCHAR(50)
);


  INSERT INTO MenuItems2 (item_id, name, description, price, category)
  VALUES (1, 'Item 1', 'Description 1', 200, 'Category 1');

  INSERT INTO MenuItems2 (item_id, name, description, price, category)
  VALUES (2, 'Item 2', 'Description 2', 150, 'Category 2');

  INSERT INTO MenuItems2 (item_id, name, description, price, category)
  VALUES (3, 'Item 3', 'Description 3', 250, 'Category 3');

  INSERT INTO MenuItems2 (item_id, name, description, price, category)
  VALUES (4, 'Item 4', 'Description 4', 175, 'Category 4');

  INSERT INTO MenuItems2 (item_id, name, description, price, category)
  VALUES (5, 'Item 5', 'Description 5', 225, 'Category 5');


CREATE TABLE Orders2 (
  order_id INT PRIMARY KEY,
  customer_id INT,
  order_date DATE,
  quantity NUMBER(10,2),
  total_amount NUMBER(10, 2),
  item_id INT,
  FOREIGN KEY (item_id) REFERENCES MenuItems2(item_id),
  FOREIGN KEY (customer_id) REFERENCES Customers2(customer_id)
);

CREATE TABLE Tables2 (
  table_id INT PRIMARY KEY,
  seats INT,
  status VARCHAR(20)
);



INSERT INTO Tables2 (table_id, seats, status)
VALUES (6, 8, 'Unavailable');

INSERT INTO Tables2 (table_id, seats, status)
VALUES (7, 6, 'Unavailable');

INSERT INTO Tables2 (table_id, seats, status)
VALUES (8, 4, 'Unavailable');

INSERT INTO Tables2 (table_id, seats, status)
VALUES (9, 2, 'Unavailable');

INSERT INTO Tables2 (table_id, seats, status)
VALUES (10, 10, 'Unavailable');


Create TABLE Feedback2 (
fid INT PRIMARY KEY,
message VARCHAR(50)
);

	/*------------------------------------------------------------------CUSTOMERS----------------------------------------------------------------*/
/*  CUSTOMER */ 

-- SHOW USER
DECLARE

BEGIN
	 for R in (SELECT * from Customers2 join Customers1@site_link on Customers2.customer_id=Customers1.customer_id@site_link)
	 LOOP
		DBMS_OUTPUT.PUT_LINE(R.name);
	 END LOOP;
END;
/
/*	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;
	*/


-- INSERT USER
DECLARE

	cid Customers2.customer_id%TYPE := 11; 
	NAME Customers1.name@site_link%TYPE := 'Johnas Doe';
	ADDRESS Customers1.address@site_link%TYPE := '111 Main St';
	PHONE Customers2.phone_number%TYPE := '1234567890';
	EMAIL Customers2.email%TYPE := 'johndoe@example.com';
	GENDER Customers2.gender%TYPE := 'M';
BEGIN
    insert into Customers2 values (cid, PHONE, EMAIL, GENDER);
    insert into Customers1@site_link values (cid, NAME, ADDRESS, GENDER);
END;
/

-- delete user
DECLARE

	cid Customers2.customer_id%TYPE := &DEL_USER;
BEGIN
    delete Customers2 where customer_id=cid;
	delete Customers1@site_link where Customers1.customer_id@site_link=cid;
END;
/

-- update user
DECLARE

	cid Customers2.customer_id%TYPE := &DEL_USER;
BEGIN
    update Customers2 set email='abc@gmail.com' where customer_id=cid;
    update Customers1@site_link set address='tha 24,khilgaon' where Customers1.customer_id@site_link=cid;
END;
/

	/*------------------------------------------------------------------MENUITEM----------------------------------------------------------------*/

/*  MENU ITEM */ 
DECLARE

BEGIN
	 for R in (SELECT * from MenuItems2 join MenuItems1@site_link on MenuItems2.item_id=MenuItems1.item_id@site_link)
	 LOOP
		DBMS_OUTPUT.PUT_LINE(R.price);
	 END LOOP;
END;
/
/*	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;
	*/


DECLARE
  ITEM MenuItems2.item_id%TYPE := &x; 
  ITEM_NAME MenuItems2.name%TYPE := &x;  
  ITEM_DES MenuItems2.description%TYPE := &x; 
  ITEM_PRICE MenuItems2.price%TYPE := &x;  
  ITEM_CAT MenuItems2.category%TYPE := &x;
  highprice_exception EXCEPTION;  
BEGIN
	if (price<=250)THEN
	    insert into MenuItems2 values (item_id,name,description,price,category);
    ELSIF (price>250 AND price<=2000)
	    insert into MenuItems1@site_link values (item_id,name,description,price,category);
	ELSE 
		raise highprice_exception;
	End if;

EXCEPTION
	WHEN highprice_exception THEN
		DBMS_OUTPUT.PUT_LINE('Price Cant be > then 2000');
END;
/





















































CREATE OR REPLACE PACKAGE USERS AS
  Procedure SHOW_USER(CID in Customers2.customer_id%TYPE);
  PROCEDURE INSERT_USER(cid in Customers2.customer_id%TYPE,NAME in Customers1.name@site_link%TYPE, ADDRESS in Customers1.address@site_link%TYPE,
    PHONE in Customers2.phone_number%TYPE, EMAIL in Customers2.email%TYPE, GENDER in Customers2.gender%TYPE);
END USERS;
/
 
CREATE OR REPLACE PACKAGE BODY USERS AS
  Procedure SHOW_USER(CID in Customers2.customer_id%TYPE)
  IS 
  BEGIN
    for R in (SELECT * from Customers2 join Customers1@site_link on Customers2.customer_id=Customers1.customer_id@site_link where Customers2.customer_id=CID)
    LOOP	
      DBMS_OUTPUT.PUT_LINE(R.customer_id);
      DBMS_OUTPUT.PUT_LINE(R.name);
      DBMS_OUTPUT.PUT_LINE(R.address);
      DBMS_OUTPUT.PUT_LINE(R.phone_number);
      DBMS_OUTPUT.PUT_LINE(R.email);
      DBMS_OUTPUT.PUT_LINE(R.gender);
    END LOOP; 
  END SHOW_USER;

  PROCEDURE INSERT_USER(cid in Customers2.customer_id%TYPE,NAME in Customers1.name@site_link%TYPE, ADDRESS in Customers1.address@site_link%TYPE,
    PHONE in Customers2.phone_number%TYPE, EMAIL in Customers2.email%TYPE, GENDER in Customers2.gender%TYPE)
  IS
  BEGIN
    insert into Customers2 values (cid, PHONE, EMAIL, GENDER);
    insert into Customers1@site_link values (cid, NAME, ADDRESS, GENDER);
  END INSERT_USER;
END USERS;
/



DECLARE

	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;

BEGIN
	mypack.SHOW_USER(cid);
END;
/











CREATE OR REPLACE PACKAGE BODY USERS AS
  Procedure SHOW_USER(ID in Customers2.customer_id%TYPE)
  IS 
  BEGIN
    for R in (SELECT * from Customers2 join Customers1@site_link on Customers2.customer_id=Customers1@site_link.customer_id);
    LOOP	
      DBMS_OUTPUT.PUT_LINE(R.customer_id);
      DBMS_OUTPUT.PUT_LINE(R.name);
      DBMS_OUTPUT.PUT_LINE(R.address);
      DBMS_OUTPUT.PUT_LINE(R.phone_number);
      DBMS_OUTPUT.PUT_LINE(R.email);
      DBMS_OUTPUT.PUT_LINE(R.gender);
    END LOOP;
  END SHOW_USER;
END USERS;
/

DECLARE
	cid Customers2.customer_id%TYPE := 1; -- Replace with actual values
	NAME Customers1@site_link.name%TYPE := 'John Doe';
	ADDRESS Customers1@site_link.address%TYPE := '1 Main St';
	PHONE Customers2.phone_number%TYPE := '1234567890';
	EMAIL Customers2.email%TYPE := 'johndoe@example.com';
	GENDER Customers2.gender%TYPE := 'M';
BEGIN
	USERS.SHOW_USER(cid);
END;
/





























create or replace Procedure SHOW_USER(ID in Customers2.customer_id%TYPE)
IS 

BEGIN
	 for R in (SELECT * from Customers2 join Customers1@site_link on Customers2.customer_id=Customers1.customer_id@site_link)
	 LOOP	
      DBMS_OUTPUT.PUT_LINE(R.customer_id);
      DBMS_OUTPUT.PUT_LINE(R.name);
      DBMS_OUTPUT.PUT_LINE(R.address);
      DBMS_OUTPUT.PUT_LINE(R.phone_number);
      DBMS_OUTPUT.PUT_LINE(R.email);
      DBMS_OUTPUT.PUT_LINE(R.gender);
	 END LOOP;
END SHOW_USER;
/


CREATE OR REPLACE PROCEDURE outParam(A IN money.id%TYPE,B OUT money.id%TYPE)
IS

BEGIN
	B:= 10;
	DBMS_OUTPUT.PUT_LINE(A);

END outParam;
/


DECLARE
	NUM money.id%TYPE;
BEGIN
	outParam(2,NUM);
	DBMS_OUTPUT.PUT_LINE(NUM);
END;
/


SELECT text
FROM user_errors
WHERE name = 'USERS';




CREATE OR REPLACE PROCEDURE SHOW_USER (
  ID IN Customers2.customer_id%TYPE
)
IS
  CURSOR c1 IS
    SELECT *
    FROM   Customers2
           JOIN Customers1@site_link
             ON Customers2.customer_id = Customers1.customer_id@site_link
    WHERE  Customers2.customer_id = ID;
  r1 c1%ROWTYPE;
BEGIN
  OPEN c1;
  FETCH c1 INTO r1;
  IF c1%NOTFOUND THEN
    DBMS_OUTPUT.PUT_LINE('No customer found with ID ' || ID);
  ELSE
    DBMS_OUTPUT.PUT_LINE(r1.customer_id || ' ' || r1.name || ' ' || r1.address || ' ' || r1.phone_number || ' ' || r1.email || ' ' || r1.gender);
  END IF;
  CLOSE c1;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An error has occurred: ' || SQLERRM);
END SHOW_USER;
