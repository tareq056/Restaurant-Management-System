set serveroutput on;
set verify off;

CREATE TABLE Customers1 (
  customer_id INT PRIMARY KEY,
  name VARCHAR(100),
  address VARCHAR(200),
  gender VARCHAR(20)
);



insert into Customers1 (customer_id, name, address, gender) VALUES (1, 'John Doe', '123 Main St', 'Male');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (2, 'Jane Doe', '456 Elm St', 'Female');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (3, 'Bob Smith', '789 Oak St',  'Male');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (4, 'Sally Johnson', '246 Pine St',  'Female');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (5, 'Tom Davis', '369 Cedar St', 'Male');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (6, 'Emily Brown', '159 Maple St',  'Female');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (7, 'Michael Jackson', '753 Cedar St',  'Male');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (8, 'Kim Kardashian', '951 Maple St',  'Female');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (9, 'David Beckham', '147 Cedar St', 'Male');
INSERT INTO Customers1 (customer_id, name, address, gender) VALUES (10, 'Jennifer Lopez', '753 Elm St', 'Female');







CREATE TABLE MenuItems1 (
  item_id INT PRIMARY KEY,
  name VARCHAR(100),
  description VARCHAR(200),
  price NUMBER(10, 2),
  category VARCHAR(50)
);




 INSERT INTO MenuItems1 (item_id, name, description, price, category) 
  VALUES (6, 'Item 6', 'Description 6', 275, 'Category 6'); 
 
  INSERT INTO MenuItems (item_id, name, description, price, category) 
  VALUES (7, 'Item 7', 'Description 7', 300, 'Category 7'); 
 
  INSERT INTO MenuItems1 (item_id, name, description, price, category) 
  VALUES (8, 'Item 8', 'Description 8', 325, 'Category 8'); 
 
  INSERT INTO MenuItems1 (item_id, name, description, price, category) 
  VALUES (9, 'Item 9', 'Description 9', 350, 'Category 9'); 
 
  INSERT INTO MenuItems1 (item_id, name, description, price, category) 
  VALUES (10, 'Item 10', 'Description 10', 400, 'Category 10');






CREATE TABLE Orders1 (
  order_id INT PRIMARY KEY,
  customer_id INT,
  order_date DATE,
  quantity NUMBER(10,2),
  total_amount NUMBER(10, 2),
  item_id INT,
  FOREIGN KEY (item_id) REFERENCES MenuItems1(item_id),
  FOREIGN KEY (customer_id) REFERENCES Customers1(customer_id)
);

CREATE TABLE Tables1 (
  table_id INT PRIMARY KEY,
  seats INT,
  status VARCHAR(20)
);


INSERT INTO Tables1 (table_id, seats, status) 
VALUES (1, 4, 'Available'); 
 
INSERT INTO Tables1 (table_id, seats, status) 
VALUES (2, 6, 'Available'); 
 
INSERT INTO Tables1 (table_id, seats, status) 
VALUES (3, 8, 'Available'); 
 
INSERT INTO Tables1 (table_id, seats, status) 
VALUES (4, 4, 'Available'); 
 
INSERT INTO Tables1 (table_id, seats, status) 
VALUES (5, 2, 'Available');




CREATE TABLE Reservations (
  reservation_id INT PRIMARY KEY,
  customer_id INT,
  table_id INT,
  reservation_date DATE,
  guests INT,
  FOREIGN KEY (customer_id) REFERENCES Customers1(customer_id),
  FOREIGN KEY (table_id) REFERENCES Tables1(table_id)
);

Create TABLE Feedback1 (
fid INT PRIMARY KEY,
customer_id INT,
item_id INT,
FOREIGN KEY (customer_id) REFERENCES Customers1(customer_id),
FOREIGN KEY (item_id) REFERENCES MenuItems1(item_id)
);



	/*------------------------------------------------------------------CUSTOMERS----------------------------------------------------------------*/
/*  CUSTOMER */ 

-- SHOW USER
DECLARE

BEGIN
	 for R in (SELECT * from Customers1 join Customers2@site_link on Customers1.customer_id=Customers2.customer_id@site_link)
	 LOOP
		DBMS_OUTPUT.PUT_LINE(R.name);
	 END LOOP;
END;
/
/*	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;
	*/


-- INSERT USER
DECLARE

	cid Customers1.customer_id%TYPE := 11; 
	NAME Customers1.name%TYPE := 'Johnas Doe';
	ADDRESS Customers1.address%TYPE := '111 Main St';
	PHONE Customers2.phone_number@site_link%TYPE := '1234567890';
	EMAIL Customers2.email@site_link%TYPE := 'johndoe@example.com';
	GENDER Customers2.gender@site_link%TYPE := 'M';
BEGIN
    insert into Customers2@site_link values (cid, PHONE, EMAIL, GENDER);
    insert into Customers1 values (cid, NAME, ADDRESS, GENDER);
END;
/

-- delete user
DECLARE

	cid Customers1.customer_id%TYPE := &DEL_USER;
BEGIN
    delete Customers2@site_link where Customers2.customer_id@site_link=cid;
	delete Customers1 where customer_id=cid;
END;
/

-- update user
DECLARE

	cid Customers1.customer_id%TYPE := &UP_USER;
BEGIN
    update Customers2@site_link set email='abc@gmail.com' where Customers2.customer_id.@site_link=cid;
    update Customers1 set address='tha 24,khilgaon' where customer_id=cid;
END;
/



	/*------------------------------------------------------------------MENUITEM----------------------------------------------------------------*/

/*  MENU ITEM */ 
DECLARE

BEGIN
	 for R in (SELECT * from MenuItems1 join MenuItems2@site_link on MenuItems1.item_id=MenuItems2.item_id@site_link)
	 LOOP
		DBMS_OUTPUT.PUT_LINE(R.price);
	 END LOOP;
END;
/
/*	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;
	*/


DECLARE
  ITEM MenuItems1.item_id%TYPE := &x; 
  ITEM_NAME MenuItems1.name%TYPE := &x;  
  ITEM_DES MenuItems1.description%TYPE := &x; 
  ITEM_PRICE MenuItems1.price%TYPE := &x;  
  ITEM_CAT MenuItems1.category%TYPE := &x;
  highprice_exception EXCEPTION;  
BEGIN
	if (price<=250)THEN
	    insert into MenuItems2 values (item_id,name,description,price,category);
    ELSIF (price>250 AND price<=2000)
	    insert into MenuItems1@site_link values (item_id,name,description,price,category);
	ELSE 
		raise highprice_exception;
	End if;

EXCEPTION
	WHEN highprice_exception THEN
		DBMS_OUTPUT.PUT_LINE('Price Cant be > then 2000');
END;
/




























CREATE OR REPLACE PACKAGE USERS AS
  Procedure SHOW_USER(CID in Customers1.customer_id%TYPE);
  PROCEDURE INSERT_USER(cid in Customers1.customer_id%TYPE,NAME in Customers1.nameTYPE, ADDRESS in Customers1.address%TYPE,
    PHONE in Customers2.phone_number@site_link%TYPE, EMAIL in Customers2.email@site_link%TYPE, GENDER in Customers1.gender%TYPE);
END USERS;
/
 
CREATE OR REPLACE PACKAGE BODY USERS AS
  Procedure SHOW_USER(CID in Customers1.customer_id%TYPE)
  IS 
  BEGIN
    for R in (SELECT * from Customers1 join Customers2@site_link on Customers1.customer_id=Customers2.customer_id@site_link where Customers1.customer_id=CID)
    LOOP	
      DBMS_OUTPUT.PUT_LINE(R.customer_id);
      DBMS_OUTPUT.PUT_LINE(R.name);
      DBMS_OUTPUT.PUT_LINE(R.address);
      DBMS_OUTPUT.PUT_LINE(R.phone_number);
      DBMS_OUTPUT.PUT_LINE(R.email);
      DBMS_OUTPUT.PUT_LINE(R.gender);
    END LOOP; 
  END SHOW_USER;

  PROCEDURE INSERT_USER(cid in Customers1.customer_id%TYPE,NAME in Customers1.nameTYPE, ADDRESS in Customers1.address%TYPE,
    PHONE in Customers2.phone_number@site_link%TYPE, EMAIL in Customers2.email@site_link%TYPE, GENDER in Customers1.gender%TYPE)
  IS
  BEGIN
    insert into Customers2@site_link values (cid, PHONE, EMAIL, GENDER);
    insert into Customers1 values (cid, NAME, ADDRESS, GENDER);
  END INSERT_USER;
END USERS;
/



DECLARE

	cid Customers2.customer_id%TYPE := &CID;
	NAME Customers1@site_link.name%TYPE := &NM; 
	ADDRESS Customers1@site_link.address%TYPE := &AD;
	PHONE Customers2.phone_number%TYPE := &PHN; 
	EMAIL Customers2.email%TYPE := &EML;
	GENDER Customers2.gender%TYPE := &GNDR;

BEGIN
	USERS.SHOW_USER(cid);
	USERS.INSERT_USER(cid,NAME,ADDRESS,PHONE,EMAIL.GENDER);
END;
/



