drop TABLE Feedback;
drop TABLE Reservations;
drop TABLE Tables;
drop TABLE Suppliers;
drop TABLE Inventory;
drop TABLE Employees;

drop TABLE Orders;

drop table MenuItems;
drop TABLE Customers;
-- Create Customers table
CREATE TABLE Customers (
  customer_id INT PRIMARY KEY,
  name VARCHAR(100),
  address VARCHAR(200),
  phone_number VARCHAR(20),
  email VARCHAR(100),
  gender VARCHAR(20)
);
-- Create Menu Items table
CREATE TABLE MenuItems (
  item_id INT PRIMARY KEY,
  name VARCHAR(100),
  description VARCHAR(200),
  price NUMBER(10, 2),
  category VARCHAR(50)
);

-- Create Orders table
CREATE TABLE Orders (
  order_id INT PRIMARY KEY,
  customer_id INT,
  order_date DATE,
  total_amount NUMBER(10, 2),
  item_id INT,
  FOREIGN KEY (item_id) REFERENCES MenuItems(item_id),
  FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);



-- Create Employees table
CREATE TABLE Employees (
  employee_id INT PRIMARY KEY,
  name VARCHAR(100),
  position VARCHAR(50),
  phone_number VARCHAR(20),
  email VARCHAR(100)
);

-- Create Inventory table
CREATE TABLE Inventory (
  item_id INT PRIMARY KEY,
  quantity INT,
  reorder_point INT,
  cost NUMBER(10, 2),
  FOREIGN KEY (item_id) REFERENCES MenuItems(item_id)
);

-- Create Suppliers table
CREATE TABLE Suppliers (
  supplier_id INT PRIMARY KEY,
  name VARCHAR(100),
  address VARCHAR(200),
  phone_number VARCHAR(20),
  email VARCHAR(100)
);

-- Create Tables table
CREATE TABLE Tables (
  table_id INT PRIMARY KEY,
  seats INT,
  status VARCHAR(20)
);

-- Create Reservations table
CREATE TABLE Reservations (
  reservation_id INT PRIMARY KEY,
  customer_id INT,
  table_id INT,
  reservation_date DATE,
  guests INT,
  FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
  FOREIGN KEY (table_id) REFERENCES Tables(table_id)
);
-- CREATE Feedback TABLE
Create Feedback (
fid INT PRIMARY KEY,
customer_id INT,
item_id INT,
message VARCHAR(50),
FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
FOREIGN KEY (item_id) REFERENCES MenuItems(item_id)
)
